import java.awt.*;
import java.applet.*;

public class Q1B extends Applet implements Runnable {
    private int x = 0; // initial x-coordinate of the car

    public void start() {
        Thread t = new Thread(this);
        t.start(); // start the thread
    }

    public void run() {
        while (true) {
            try {
                // Move the car horizontally by incrementing x-coordinate
                x += 5;
                if (x > getWidth()) {
                    x = 0; // reset x-coordinate when the car goes beyond the applet boundary
                }
                repaint(); // repaint the applet to display the updated position of the car
                Thread.sleep(100); // sleep for 100 milliseconds before moving the car again
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public void paint(Graphics g) {
        // Set the color of the car body
        g.setColor(Color.blue);
        // Draw the car body
        g.fillRect(x, getHeight() / 2 - 10, 60, 20);
        // Draw the wheels
        g.setColor(Color.black);
        g.fillOval(x + 10, getHeight() / 2 + 10, 10, 10);
        g.fillOval(x + 40, getHeight() / 2 + 10, 10, 10);
    }
}
