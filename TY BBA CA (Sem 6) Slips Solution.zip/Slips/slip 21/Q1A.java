public class Q1A {
    public static void main(String[] args) {
        Thread mainThread = Thread.currentThread();

        System.out.println("Thread Name: " + mainThread.getName());
        System.out.println("Thread Priority: " + mainThread.getPriority());
    }
}
