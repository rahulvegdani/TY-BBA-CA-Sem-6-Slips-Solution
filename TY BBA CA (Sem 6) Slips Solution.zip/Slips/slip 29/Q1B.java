import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Q1B extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Get the requested session, create a new session if one doesn't exist
        HttpSession session = request.getSession(true);

        // Set session inactive time to 5 minutes (300 seconds)
        session.setMaxInactiveInterval(300);

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Session Timeout Changed</title>");
        out.println("</head>");
        out.println("<body>");
        out.println("<h2>Session Timeout Changed</h2>");
        out.println("<p>The inactive time interval of the session has been changed to 5 minutes.</p>");
        out.println("</body>");
        out.println("</html>");
    }

    // For demonstration purposes, you can use either doGet or doPost method
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }
}
