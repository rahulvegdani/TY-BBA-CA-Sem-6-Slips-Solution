import java.awt.Color;
import java.awt.Graphics;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Q1B extends JPanel implements Runnable {
    private static final long serialVersionUID = 1L;
    private static final int WIDTH = 300;
    private static final int HEIGHT = 500;
    private static final Color SAFFRON = new Color(244, 196, 48);
    private static final Color WHITE = new Color(255, 255, 255);
    private static final Color GREEN = new Color(80, 158, 47);
    private int x;
    private int y;
    private int stripeWidth;
    private int stripeHeight;
    private int stripeCount;

    public Q1B() {
        this.x = 0;
        this.y = 0;
        this.stripeWidth = WIDTH / 3;
        this.stripeHeight = HEIGHT / 3;
        this.stripeCount = 0;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setColor(SAFFRON);
        g.fillRect(x, y, stripeWidth, stripeHeight);
        g.setColor(WHITE);
        g.fillRect(x + stripeWidth, y, stripeWidth, stripeHeight);
        g.setColor(GREEN);
        g.fillRect(x + (2 * stripeWidth), y, stripeWidth, stripeHeight);
    }

    @Override
    public void run()

    {
        while (stripeCount < 3) {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            if (stripeCount % 2 == 0) {
                x += 10;
            } else {
                x -= 10;
            }
            stripeCount++;
            repaint();
        }
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Flag of India");
        frame.setSize(WIDTH, HEIGHT);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Q1B frenchFlag = new Q1B();
        frame.add(frenchFlag);
        ExecutorService executor = Executors.newFixedThreadPool(1);
        executor.execute(frenchFlag);
        frame.setVisible(true);
    }
}