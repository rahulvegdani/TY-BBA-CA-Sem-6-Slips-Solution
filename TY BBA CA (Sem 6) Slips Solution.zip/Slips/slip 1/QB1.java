import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;

public class QB1 extends JFrame {
    private JTextField messageField;
    private JTextArea chatArea;
    private ObjectOutputStream outputStream;
    private ObjectInputStream inputStream;
    private Socket socket;

    public QB1() {
        super("Chat Application");
        messageField = new JTextField();
        messageField.setEditable(false);
        messageField.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                sendMessage(event.getActionCommand());
                messageField.setText("");
            }
        });
        add(messageField, BorderLayout.NORTH);

        chatArea = new JTextArea();
        add(new JScrollPane(chatArea), BorderLayout.CENTER);

        setSize(300, 150);
        setVisible(true);
    }

    public void startRunning() {
        try {
            connectToServer();
            setupStreams();
            whileChatting();
        } catch (EOFException eofException) {
            showMessage("\n Server terminated the connection");
        } catch (IOException ioException) {
            ioException.printStackTrace();
        } finally {
            closeConnection();
        }
    }

    private void connectToServer() throws IOException {
        showMessage("Attempting connection... \n");
        socket = new Socket(InetAddress.getByName("127.0.0.1"), 6789);
        showMessage("Connected to: " + socket.getInetAddress().getHostName());
    }

    private void setupStreams() throws IOException {
        outputStream = new ObjectOutputStream(socket.getOutputStream());
        outputStream.flush();
        inputStream = new ObjectInputStream(socket.getInputStream());
        showMessage("\n Streams are now setup! \n");
    }

    private void whileChatting() throws IOException {
        String message = "You are now connected!";
        sendMessage(message);
        ableToType(true);
        do {
            try {
                message = (String) inputStream.readObject();
                showMessage("\n" + message);
            } catch (ClassNotFoundException classNotFoundException) {
                showMessage("\n Unknown object type received");
            }
        } while (!message.equals("SERVER - END"));
    }

    private void closeConnection() {
        showMessage("\n Closing the connection! \n");
        ableToType(false);
        try {
            outputStream.close();
            inputStream.close();
            socket.close();
        } catch (IOException ioException) {
            ioException.printStackTrace();
        }
    }

    private void sendMessage(String message) {
        try {
            outputStream.writeObject("CLIENT - " + message);
            outputStream.flush();
            showMessage("\nCLIENT - " + message);
        } catch (IOException ioException) {
            chatArea.append("\n Error: Unable to send message.");
        }
    }

    private void showMessage(final String text) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                chatArea.append(text);
            }
        });
    }

    private void ableToType(final boolean tof) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                messageField.setEditable(tof);
            }
        });
    }

    public static void main(String[] args) {
        QB1 chatClient = new QB1();
        chatClient.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        chatClient.startRunning();
    }
}
