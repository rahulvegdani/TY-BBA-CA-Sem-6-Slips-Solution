MainActivity.java

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "game_db";
    private static final String TABLE_GAME = "games";
    private static final String KEY_GNO = "gno";
    private static final String KEY_GNAME = "gname";
    private static final String KEY_TYPE = "type";
    private static final String KEY_NO_OF_PLAYERS = "no_of_players";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_GAME_TABLE = "CREATE TABLE " + TABLE_GAME + "("
                + KEY_GNO + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + KEY_GNAME + " TEXT,"
                + KEY_TYPE + " TEXT,"
                + KEY_NO_OF_PLAYERS + " INTEGER" + ")";
        db.execSQL(CREATE_GAME_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GAME);
        onCreate(db);
    }

    public void addGame(Game game) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_GNAME, game.getGname());
        values.put(KEY_TYPE, game.getType());
        values.put(KEY_NO_OF_PLAYERS, game.getNo_of_players());
        db.insert(TABLE_GAME, null, values);
        db.close();
    }

    public void updateNoOfPlayersForBadminton() {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_NO_OF_PLAYERS, 4);
        db.update(TABLE_GAME, values, KEY_GNAME + " = ?", new String[]{"Badminton"});
        db.close();
    }

    public List<Game> getAllGames() {
        List<Game> gameList = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + TABLE_GAME;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                Game game = new Game();
                game.setGno(Integer.parseInt(cursor.getString(0)));
                game.setGname(cursor.getString(1));
                game.setType(cursor.getString(2));
                game.setNo_of_players(Integer.parseInt(cursor.getString(3)));
                gameList.add(game);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return gameList;
    }
}
------------------------------------------------------------------------
activity_main.xml

<?xml version="1.0" encoding="utf-8"?>
<RelativeLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent">

    <EditText
        android:id="@+id/gnameEditText"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:hint="Game Name"/>

    <EditText
        android:id="@+id/typeEditText"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_below="@id/gnameEditText"
        android:hint="Type"/>

    <EditText
        android:id="@+id/noOfPlayersEditText"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_below="@id/typeEditText"
        android:inputType="number"
        android:hint="Number of Players"/>

    <Button
        android:id="@+id/addButton"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_below="@id/noOfPlayersEditText"
        android:text="Add Game"/>

    <Button
        android:id="@+id/updateButton"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_below="@id/addButton"
        android:text="Update No of Players for Badminton"/>

    <Button
        android:id="@+id/showButton"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_below="@id/updateButton"
        android:text="Show All Records"/>

    <ListView
        android:id="@+id/gameListView"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_below="@id/showButton"
        android:layout_marginTop="16dp"/>

</RelativeLayout>
--------------------------------------------------------------------------------
GameListAdapter.java

package com.example.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import java.util.List;

public class GameListAdapter extends ArrayAdapter<Game> {

    private Context context;
    private List<Game> games;

    public GameListAdapter(Context context, List<Game> games) {
        super(context, 0, games);
        this.context = context;
        this.games = games;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View listItem = convertView;
        if (listItem == null) {
            listItem = LayoutInflater.from(context).inflate(R.layout.list_item_game, parent, false);
        }

        Game currentGame = games.get(position);

        TextView gnoTextView = listItem.findViewById(R.id.gnoTextView);
        gnoTextView.setText(String.valueOf(currentGame.getGno()));

        TextView gnameTextView = listItem.findViewById(R.id.gnameTextView);
        gnameTextView.setText(currentGame.getGname());

        TextView typeTextView = listItem.findViewById(R.id.typeTextView);
        typeTextView.setText(currentGame.getType());

        TextView noOfPlayersTextView = listItem.findViewById(R.id.noOfPlayersTextView);
        noOfPlayersTextView.setText(String.valueOf(currentGame.getNo_of_players()));

        return listItem;
    }
}
---------------------------------------------------------------------
list_item_game.xml

<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    android:orientation="vertical"
    android:padding="16dp">

    <TextView
        android:id="@+id/gnoTextView"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:textStyle="bold"/>

    <TextView
        android:id="@+id/gnameTextView"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"/>

    <TextView
        android:id="@+id/typeTextView"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"/>

    <TextView
        android:id="@+id/noOfPlayersTextView"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"/>

</LinearLayout>
------------------------------------------------------------------
Game.java

package com.example.myapplication;

public class Game {
    private int gno;
    private String gname;
    private String type;
    private int no_of_players;

    public Game() {
    }

    public Game(int gno, String gname, String type, int no_of_players) {
        this.gno = gno;
        this.gname = gname;
        this.type = type;
        this.no_of_players = no_of_players;
    }

    public int getGno() {
        return gno;
    }

    public void setGno(int gno) {
        this.gno = gno;
    }

    public String getGname() {
        return gname;
    }

    public void setGname(String gname) {
        this.gname = gname;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getNo_of_players() {
        return no_of_players;
    }

    public void setNo_of_players(int no_of_players) {
        this.no_of_players = no_of_players;
    }

    @Override
    public String toString() {
        return "Game{" +
                "gno=" + gno +
                ", gname='" + gname + '\'' +
                ", type='" + type + '\'' +
                ", no_of_players=" + no_of_players +
                '}';
    }
}
----------------------------------------------------------------------
DatabaseHelper.java

package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "game_db";
    private static final String TABLE_GAME = "games";
    private static final String KEY_GNO = "gno";
    private static final String KEY_GNAME = "gname";
    private static final String KEY_TYPE = "type";
    private static final String KEY_NO_OF_PLAYERS = "no_of_players";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_GAME_TABLE = "CREATE TABLE " + TABLE_GAME + "("
                + KEY_GNO + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + KEY_GNAME + " TEXT,"
                + KEY_TYPE + " TEXT,"
                + KEY_NO_OF_PLAYERS + " INTEGER" + ")";
        db.execSQL(CREATE_GAME_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GAME);
        onCreate(db);
    }

    public void addGame(Game game) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_GNAME, game.getGname());
        values.put(KEY_TYPE, game.getType());
        values.put(KEY_NO_OF_PLAYERS, game.getNo_of_players());
        db.insert(TABLE_GAME, null, values);
        db.close();
    }

    public void updateNoOfPlayersForBadminton() {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_NO_OF_PLAYERS, 4);
        db.update(TABLE_GAME, values, KEY_GNAME + " = ?", new String[]{"Badminton"});
        db.close();
    }

    public List<Game> getAllGames() {
        List<Game> gameList = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + TABLE_GAME;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                Game game = new Game();
                game.setGno(Integer.parseInt(cursor.getString(0)));
                game.setGname(cursor.getString(1));
                game.setType(cursor.getString(2));
                game.setNo_of_players(Integer.parseInt(cursor.getString(3)));
                gameList.add(game);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return gameList;
    }
}
