import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Q1B {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Get user input for start date
        System.out.print("Enter start date (yyyy-MM-dd): ");
        String startDateStr = scanner.nextLine();

        // Get user input for end date
        System.out.print("Enter end date (yyyy-MM-dd): ");
        String endDateStr = scanner.nextLine();

        // Parse the dates
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date startDate = dateFormat.parse(startDateStr);
            Date endDate = dateFormat.parse(endDateStr);

            // Display sales details
            displaySalesDetails(startDate, endDate);

        } catch (ParseException e) {
            System.out.println("Invalid date format. Please use yyyy-MM-dd format.");
        }

        scanner.close();
    }

    public static void displaySalesDetails(Date startDate, Date endDate) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            // Establish connection to the database
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/sales_product", "root", "root");

            // Prepare SQL statement to select sales details between two dates
            String sql = "SELECT PID, PName, Qty, Rate, Amount FROM Sales WHERE Date BETWEEN ? AND ?";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setDate(1, new java.sql.Date(startDate.getTime()));
            preparedStatement.setDate(2, new java.sql.Date(endDate.getTime()));

            // Execute the query
            resultSet = preparedStatement.executeQuery();

            // Display the results
            System.out.println("Sales details between " + startDate + " and " + endDate + ":");
            System.out.println("PID\tPName\tQty\tRate\tAmount");
            while (resultSet.next()) {
                System.out.println(resultSet.getInt("PID") + "\t"
                        + resultSet.getString("PName") + "\t"
                        + resultSet.getInt("Qty") + "\t"
                        + resultSet.getDouble("Rate") + "\t"
                        + resultSet.getDouble("Amount"));
            }

        } catch (SQLException e) {
            System.out.println("Error fetching sales details: " + e.getMessage());
        } finally {
            // Close the connection, statement, and result set
            try {
                if (resultSet != null)
                    resultSet.close();
                if (preparedStatement != null)
                    preparedStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                System.out.println("Error closing database resources: " + e.getMessage());
            }
        }
    }
}


/*
-- Create a Sales table
CREATE TABLE Sales (
    PID INT AUTO_INCREMENT PRIMARY KEY,
    PName VARCHAR(50),
    Qty INT,
    Rate DECIMAL(10, 2),
    Amount DECIMAL(10, 2),
    Date DATE
);

-- Insert sample data into the Sales table
INSERT INTO Sales (PName, Qty, Rate, Amount, Date) VALUES
('Product A', 5, 10.00, 50.00, '2024-04-01'),
('Product B', 3, 15.00, 45.00, '2024-04-02'),
('Product C', 2, 20.00, 40.00, '2024-04-03');*/
