import java.applet.*;
import java.awt.*;

public class Q1B extends Applet implements Runnable {
    private Thread t1, t2, t3; // Threads for drawing different parts of the temple

    public void init() {
        setBackground(Color.white);
    }

    public void start() {
        t1 = new Thread(this);
        t2 = new Thread(this);
        t3 = new Thread(this);
        t1.start(); // Start threads
        t2.start();
        t3.start();
    }

    public void run() {
        Thread currentThread = Thread.currentThread();
        Graphics g = getGraphics();

        if (currentThread == t1) {
            drawPillars(g); // Draw pillars
        } else if (currentThread == t2) {
            drawDome(g); // Draw dome
        } else if (currentThread == t3) {
            drawMainBuilding(g); // Draw main building
        }
    }

    public void stop() {
        if (t1 != null) t1.interrupt();
        if (t2 != null) t2.interrupt();
        if (t3 != null) t3.interrupt();
    }

    public void paint(Graphics g) {
        // Draw ground
        g.setColor(Color.green);
        g.fillRect(0, 400, 600, 200);
    }

    public void drawPillars(Graphics g) {
        // Draw pillars
        g.setColor(Color.gray);
        for (int i = 0; i < 6; i++) {
            g.fillRect(100 + i * 80, 200, 20, 200);
        }
    }

    public void drawDome(Graphics g) {
        // Draw dome
        g.setColor(Color.orange);
        g.fillOval(140, 50, 300, 200);
    }

    public void drawMainBuilding(Graphics g) {
        // Draw main building
        g.setColor(Color.yellow);
        g.fillRect(200, 200, 200, 200);
    }
}
