import java.util.Random;

public class Q1B extends Thread {
    private static final Random RANDOM = new Random();
    private static final int MAX_SLEEP_TIME = 5000; // Maximum sleep time in milliseconds

    public Q1B(String name) {
        super(name);
    }

    @Override
    public void run() {
        try {
            System.out.println(getName() + " is created.");
            int sleepTime = RANDOM.nextInt(MAX_SLEEP_TIME);
            System.out.println(getName() + " will sleep for " + sleepTime + " milliseconds.");
            Thread.sleep(sleepTime);
            System.out.println(getName() + " is dead.");
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        Q1B thread = new Q1B("CustomThread");
        thread.start();
    }
}
