import java.net.InetAddress;

public class Q1A {
    public static void main(String[] args) {
        try {
            InetAddress localHost = InetAddress.getLocalHost();
            String ipAddress = localHost.getHostAddress();
            String hostName = localHost.getHostName();

            System.out.println("IP Address: " + ipAddress);
            System.out.println("Host Name: " + hostName);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
