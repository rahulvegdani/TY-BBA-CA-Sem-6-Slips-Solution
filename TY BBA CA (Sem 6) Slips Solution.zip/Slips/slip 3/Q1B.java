import java.applet.Applet;
import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;

public class Q1B extends Applet implements Runnable {
    private int x, y; // Coordinates of the ball
    private int dx = 2, dy = 2; // Incremental change in position
    private Color ballColor; // Color of the ball
    private Random random;

    @Override
    public void init() {
        setSize(400, 400); // Set applet size
        random = new Random();
        x = getWidth() / 2; // Initial x-coordinate (center)
        y = getHeight() / 2; // Initial y-coordinate (center)
        ballColor = getRandomColor(); // Set initial color
    }

    @Override
    public void start() {
        Thread thread = new Thread(this);
        thread.start(); // Start the animation thread
    }

    @Override
    public void run() {
        while (true) {
            moveBall(); // Move the ball
            repaint(); // Repaint the applet
            sleep(10); // Delay for smooth animation
        }
    }

    private void moveBall() {
        // Update ball position
        x += dx;
        y += dy;

        // Check boundaries
        if (x <= 0 || x >= getWidth()) {
            dx = -dx; // Reverse horizontal direction
            ballColor = getRandomColor(); // Change color
        }
        if (y <= 0 || y >= getHeight()) {
            dy = -dy; // Reverse vertical direction
            ballColor = getRandomColor(); // Change color
        }
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        // Set ball color
        g.setColor(ballColor);
        // Draw the ball
        g.fillOval(x, y, 20, 20); // Ball size: 20x20 pixels
    }

    private Color getRandomColor() {
        // Generate random RGB values
        int red = random.nextInt(256);
        int green = random.nextInt(256);
        int blue = random.nextInt(256);
        return new Color(red, green, blue);
    }

    private void sleep(int milliseconds) {
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
