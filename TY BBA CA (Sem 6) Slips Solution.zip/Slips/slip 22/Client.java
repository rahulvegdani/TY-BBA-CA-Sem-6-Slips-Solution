import java.io.*;
import java.net.*;
import java.util.Date;

public class Client {
    public static void main(String[] args) {
        try {
            Socket socket = new Socket("localhost", 5000);

            ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream());

            Date date = (Date) inputStream.readObject();
            System.out.println("Date and Time on Server: " + date);

            inputStream.close();
            socket.close();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
