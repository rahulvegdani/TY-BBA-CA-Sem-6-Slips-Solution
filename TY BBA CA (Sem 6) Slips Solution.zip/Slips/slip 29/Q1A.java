import java.util.Scanner;

class OddNumberThread extends Thread {
    private int n;
    private StringBuilder result;

    public OddNumberThread(int n, StringBuilder result) {
        this.n = n;
        this.result = result;
    }

    public void run() {
        result.append("Odd numbers between 1 to " + n + ":\n");
        for (int i = 1; i <= n; i++) {
            if (i % 2 != 0) {
                result.append(i).append(" ");
            }
        }
        result.append("\n");
    }
}

class PrimeNumberThread extends Thread {
    private int n;
    private StringBuilder result;

    public PrimeNumberThread(int n, StringBuilder result) {
        this.n = n;
        this.result = result;
    }

    public void run() {
        result.append("Prime numbers between 1 to " + n + ":\n");
        for (int i = 2; i <= n; i++) {
            boolean isPrime = true;
            for (int j = 2; j <= Math.sqrt(i); j++) {
                if (i % j == 0) {
                    isPrime = false;
                    break;
                }
            }
            if (isPrime) {
                result.append(i).append(" ");
            }
        }
        result.append("\n");
    }
}

public class Q1A {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the value of n: ");
        int n = scanner.nextInt();
        scanner.close();

        StringBuilder result = new StringBuilder(1000); // Initialize with sufficient capacity

        OddNumberThread oddThread = new OddNumberThread(n, result);
        PrimeNumberThread primeThread = new PrimeNumberThread(n, result);

        // Start both threads
        oddThread.start();
        primeThread.start();

        try {
            // Wait for both threads to finish
            oddThread.join();
            primeThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Print the final result
        System.out.println(result.toString());
    }
}
