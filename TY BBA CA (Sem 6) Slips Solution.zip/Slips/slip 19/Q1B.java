import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class Q1B extends JFrame {

    private JTextField rollNumberField;
    private JTextField nameField;
    private JTextField percentageField;
    private JButton displayButton;

    static final String DB_URL = "jdbc:mysql://localhost:3306/student";
    static final String USER = "root";
    static final String PASS = "root";

    public Q1B() {
        setTitle("Display First Record");
        setSize(400, 200);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        rollNumberField = new JTextField(10);
        nameField = new JTextField(10);
        percentageField = new JTextField(10);
        displayButton = new JButton("Display First Record");

        JPanel panel = new JPanel(new GridLayout(4, 2));
        panel.add(new JLabel("Roll Number:"));
        panel.add(rollNumberField);
        panel.add(new JLabel("Name:"));
        panel.add(nameField);
        panel.add(new JLabel("Percentage:"));
        panel.add(percentageField);
        panel.add(displayButton);

        displayButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                displayRecord();
            }
        });

        add(panel);
    }

    private void displayRecord() {
        try (Connection connection = DriverManager.getConnection(DB_URL, USER, PASS);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery("SELECT * FROM student LIMIT 1")) {

            if (resultSet.next()) {
                int rollNumber = resultSet.getInt("rno");
                String name = resultSet.getString("sname");
                double percentage = resultSet.getDouble("per");

                rollNumberField.setText(Integer.toString(rollNumber));
                nameField.setText(name);
                percentageField.setText(Double.toString(percentage));
            } else {
                JOptionPane.showMessageDialog(this, "No records found in the student table.");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Q1B().setVisible(true));
    }
}


/*
 CREATE TABLE student (
    rno INT PRIMARY KEY,
    sname VARCHAR(255),
    per DECIMAL(5,2)
);

INSERT INTO student (rno, sname, per) VALUES
(1, 'John Doe', 85.5),
(2, 'Jane Smith', 90.0),
(3, 'Alice Johnson', 78.2),
(4, 'Bob Williams', 88.7),
(5, 'Emma Brown', 92.3);

 */