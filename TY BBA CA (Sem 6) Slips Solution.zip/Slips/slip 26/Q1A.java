import java.sql.*;

public class Q1A {
    public static void main(String[] args) {
        // JDBC URL, username, and password
        String url = "jdbc:mysql://localhost:3306/your_database_name";
        String username = "your_username";
        String password = "your_password";

        try (Connection connection = DriverManager.getConnection(url, username, password)) {
            // SQL query to fetch college names from the College table
            String sql = "SELECT CName FROM College";

            // Create a statement
            Statement statement = connection.createStatement();

            // Execute the query and get the result set
            ResultSet resultSet = statement.executeQuery(sql);

            // Display college names from the result set
            System.out.println("List of College Names:");
            while (resultSet.next()) {
                String collegeName = resultSet.getString("CName");
                System.out.println(collegeName);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
