import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.Enumeration;

public class Q1B extends HttpServlet {
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><head><title>Request Information</title></head><body>");

        // Client information
        out.println("<h2>Client Information:</h2>");
        out.println("<b>IP Address:</b> " + request.getRemoteAddr() + "<br>");
        out.println("<b>Browser Type:</b> " + request.getHeader("User-Agent") + "<br>");

        // Server information
        out.println("<h2>Server Information:</h2>");
        out.println("<b>Server Name:</b> " + request.getServerName() + "<br>");
        out.println("<b>Server Port:</b> " + request.getServerPort() + "<br>");
        out.println("<b>Server Info:</b> " + getServletContext().getServerInfo() + "<br>");
        out.println("<b>Servlets Loaded:</b> <br>");

        // Servlets loaded
        Enumeration<String> servletNames = getServletContext().getServletNames();
        while (servletNames.hasMoreElements()) {
            String servletName = servletNames.nextElement();
            out.println("- " + servletName + "<br>");
        }

        out.println("</body></html>");
        out.close();
    }
}
