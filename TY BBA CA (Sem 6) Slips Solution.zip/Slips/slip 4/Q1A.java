import java.util.*;

class Student {
    private String name;
    private int age;
    private String address;

    public Student(String name, int age, String address) {
        this.name = name;
        this.age = age;
        this.address = address;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return "Name: " + name + ", Age: " + age + ", Address: " + address;
    }
}

public class Q1A {
    public static void main(String[] args) {
        // Create a list of students
        List<Student> studentList = new ArrayList<>();
        studentList.add(new Student("John", 20, "123 Street, City"));
        studentList.add(new Student("Smith", 22, "456 Avenue, Town"));
        studentList.add(new Student("Sara", 21, "789 Road, Village"));
        studentList.add(new Student("Sam", 19, "101 Lane, County"));

        // Display the original list of students
        System.out.println("Original list of students:");
        for (Student student : studentList) {
            System.out.println(student);
        }

        // Delete students whose names start with 'S'
        Iterator<Student> iterator = studentList.iterator();
        while (iterator.hasNext()) {
            Student student = iterator.next();
            if (student.getName().startsWith("S")) {
                iterator.remove();
            }
        }

        // Display the updated list of students
        System.out.println("\nUpdated list of students after deleting students whose names start with 'S':");
        for (Student student : studentList) {
            System.out.println(student);
        }
    }
}
