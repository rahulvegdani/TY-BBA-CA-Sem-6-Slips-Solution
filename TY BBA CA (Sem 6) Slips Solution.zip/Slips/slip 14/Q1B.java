import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class Q1B {
    public static void main(String[] args) {
        String directoryPath = "C:\\Users\\Lenovo\\OneDrive\\Desktop\\college\\third year (SEM 6)\\Slips\\slip 14"; // Replace with your directory path
        String extension = ".txt"; // Replace with your desired extension

        List<String> filesWithExtension = findFilesWithExtension(directoryPath, extension);

        if (filesWithExtension.isEmpty()) {
            System.out.println("No files with extension '" + extension + "' found in the directory.");
        } else {
            System.out.println("Files with extension '" + extension + "' in the directory:");
            for (String file : filesWithExtension) {
                System.out.println(file);
            }
        }
    }

    public static List<String> findFilesWithExtension(String directoryPath, String extension) {
        List<String> filesWithExtension = new ArrayList<>();

        File directory = new File(directoryPath);
        if (!directory.exists() || !directory.isDirectory()) {
            System.out.println("Invalid directory path.");
            return filesWithExtension;
        }

        File[] files = directory.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isFile() && file.getName().toLowerCase().endsWith(extension.toLowerCase())) {
                    filesWithExtension.add(file.getName());
                }
            }
        }

        return filesWithExtension;
    }
}
