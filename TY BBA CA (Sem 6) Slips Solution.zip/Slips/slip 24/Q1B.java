import java.sql.*;
import java.util.Scanner;

public class Q1B {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/your_database_name";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "root";

    public static void main(String[] args) {
        try (Connection connection = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
             Statement statement = connection.createStatement()) {
            createEmpTable(statement);

            Scanner scanner = new Scanner(System.in);

            int choice;
            do {
                System.out.println("Menu:");
                System.out.println("1. Insert");
                System.out.println("2. Update");
                System.out.println("3. Delete");
                System.out.println("4. Search");
                System.out.println("5. Display");
                System.out.println("6. Exit");
                System.out.print("Enter your choice: ");
                choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                        insertEmployee(connection, scanner);
                        break;
                    case 2:
                        updateEmployee(connection, scanner);
                        break;
                    case 3:
                        deleteEmployee(connection, scanner);
                        break;
                    case 4:
                        searchEmployee(connection, scanner);
                        break;
                    case 5:
                        displayEmployees(connection);
                        break;
                    case 6:
                        System.out.println("Exiting the program.");
                        break;
                    default:
                        System.out.println("Invalid choice. Please enter a number between 1 and 6.");
                        break;
                }
            } while (choice != 6);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void createEmpTable(Statement statement) throws SQLException {
        String sql = "CREATE TABLE IF NOT EXISTS Emp (" +
                     "ENo INT PRIMARY KEY," +
                     "EName VARCHAR(50)," +
                     "Salary DECIMAL(10, 2)," +
                     "Desg VARCHAR(50)" +
                     ")";
        statement.executeUpdate(sql);
    }

    private static void insertEmployee(Connection connection, Scanner scanner) throws SQLException {
        System.out.print("Enter employee number: ");
        int ENo = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter employee name: ");
        String EName = scanner.nextLine();
        System.out.print("Enter employee salary: ");
        double salary = scanner.nextDouble();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter employee designation: ");
        String desg = scanner.nextLine();

        String sql = "INSERT INTO Emp (ENo, EName, Salary, Desg) VALUES (?, ?, ?, ?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, ENo);
            preparedStatement.setString(2, EName);
            preparedStatement.setDouble(3, salary);
            preparedStatement.setString(4, desg);
            int rowsInserted = preparedStatement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Employee inserted successfully.");
            } else {
                System.out.println("Failed to insert employee.");
            }
        }
    }

    private static void updateEmployee(Connection connection, Scanner scanner) throws SQLException {
        System.out.print("Enter employee number to update: ");
        int ENo = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter new employee name: ");
        String EName = scanner.nextLine();
        System.out.print("Enter new employee salary: ");
        double salary = scanner.nextDouble();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter new employee designation: ");
        String desg = scanner.nextLine();

        String sql = "UPDATE Emp SET EName = ?, Salary = ?, Desg = ? WHERE ENo = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setString(1, EName);
            preparedStatement.setDouble(2, salary);
            preparedStatement.setString(3, desg);
            preparedStatement.setInt(4, ENo);
            int rowsUpdated = preparedStatement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Employee updated successfully.");
            } else {
                System.out.println("No employee found with the given employee number.");
            }
        }
    }

    private static void deleteEmployee(Connection connection, Scanner scanner) throws SQLException {
        System.out.print("Enter employee number to delete: ");
        int ENo = scanner.nextInt();

        String sql = "DELETE FROM Emp WHERE ENo = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, ENo);
            int rowsDeleted = preparedStatement.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Employee deleted successfully.");
            } else {
                System.out.println("No employee found with the given employee number.");
            }
        }
    }

    private static void searchEmployee(Connection connection, Scanner scanner) throws SQLException {
        System.out.print("Enter employee number to search: ");
        int ENo = scanner.nextInt();

        String sql = "SELECT * FROM Emp WHERE ENo = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, ENo);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                System.out.println("Employee found:");
                System.out.println("Employee Number: " + resultSet.getInt("ENo"));
                System.out.println("Employee Name: " + resultSet.getString("EName"));
                System.out.println("Salary: " + resultSet.getDouble("Salary"));
                System.out.println("Designation: " + resultSet.getString("Desg"));
            } else {
                System.out.println("No employee found with the given employee number.");
            }
        }
    }

    private static void displayEmployees(Connection connection) throws SQLException {
        String sql = "SELECT * FROM Emp";
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {
            System.out.println("Employee details:");
            while (resultSet.next()) {
                System.out.println("Employee Number: " + resultSet.getInt("ENo"));
                System.out.println("Employee Name: " + resultSet.getString("EName"));
                System.out.println("Salary: " + resultSet.getDouble("Salary"));
                System.out.println("Designation: " + resultSet.getString("Desg"));
                System.out.println();
            }
        }
    }
}
