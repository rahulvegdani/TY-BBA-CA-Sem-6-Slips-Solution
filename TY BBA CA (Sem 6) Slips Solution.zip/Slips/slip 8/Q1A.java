import java.util.ArrayList;
import java.util.List;

public class Q1A {
    public static void main(String[] args) {
        // List of employee names
        List<String> employeeNames = new ArrayList<>();
        employeeNames.add("Alice");
        employeeNames.add("Bob");
        employeeNames.add("Anna");
        employeeNames.add("Alex");
        employeeNames.add("David");

        // Display employee names whose initial character is 'A'
        System.out.println("Employee names starting with 'A':");
        for (String name : employeeNames) {
            if (name.charAt(0) == 'A') {
                System.out.println(name);
            }
        }
    }
}
