import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Q1B extends JFrame {
    private JTextField txtRollNo, txtName, txtPercentage, txtClass;
    private JRadioButton rbMale, rbFemale;
    private JButton btnSave;

    public Q1B() {
        setTitle("Student Details Form");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(6, 2));

        JLabel lblRollNo = new JLabel("Roll No:");
        txtRollNo = new JTextField();
        add(lblRollNo);
        add(txtRollNo);

        JLabel lblName = new JLabel("Name:");
        txtName = new JTextField();
        add(lblName);
        add(txtName);

        JLabel lblPercentage = new JLabel("Percentage:");
        txtPercentage = new JTextField();
        add(lblPercentage);
        add(txtPercentage);

        JLabel lblGender = new JLabel("Gender:");
        rbMale = new JRadioButton("Male");
        rbFemale = new JRadioButton("Female");
        ButtonGroup genderGroup = new ButtonGroup();
        genderGroup.add(rbMale);
        genderGroup.add(rbFemale);
        JPanel genderPanel = new JPanel(new FlowLayout());
        genderPanel.add(rbMale);
        genderPanel.add(rbFemale);
        add(lblGender);
        add(genderPanel);

        JLabel lblClass = new JLabel("Class:");
        txtClass = new JTextField();
        add(lblClass);
        add(txtClass);

        btnSave = new JButton("Save");
        add(new JLabel()); // Placeholder
        add(btnSave);

        btnSave.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                saveStudentDetails();
            }
        });
    }

    private void saveStudentDetails() {
        String rollNo = txtRollNo.getText();
        String name = txtName.getText();
        String percentage = txtPercentage.getText();
        String gender = rbMale.isSelected() ? "Male" : "Female";
        String studentClass = txtClass.getText();

        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/your_database_name", "your_username", "your_password");
            PreparedStatement statement = connection.prepareStatement("INSERT INTO Student (RNo, SName, Per, Gender, Class) VALUES (?, ?, ?, ?, ?)");
            statement.setString(1, rollNo);
            statement.setString(2, name);
            statement.setString(3, percentage);
            statement.setString(4, gender);
            statement.setString(5, studentClass);

            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(this, "Student details saved successfully!");
            } else {
                JOptionPane.showMessageDialog(this, "Failed to save student details.", "Error", JOptionPane.ERROR_MESSAGE);
            }

            statement.close();
            connection.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                Q1B form = new Q1B();
                form.setVisible(true);
            }
        });
    }
}
