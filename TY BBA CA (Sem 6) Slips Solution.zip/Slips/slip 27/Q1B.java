import java.sql.*;

public class Q1B {
    public static void main(String[] args) {
        // JDBC URL, username, and password
        String url = "jdbc:mysql://localhost:3306/your_database_name";
        String username = "your_username";
        String password = "your_password";

        try (Connection connection = DriverManager.getConnection(url, username, password);
             Statement statement = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY)) {
            // SQL query to select all teachers
            String sql = "SELECT * FROM Teacher";
            ResultSet resultSet = statement.executeQuery(sql);

            // Move the cursor to the last row
            resultSet.last();

            // Get the row count
            int rowCount = resultSet.getRow();

            System.out.println("Total rows: " + rowCount);
            System.out.println("Displaying teacher details:");

            // Move the cursor to the first row
            resultSet.beforeFirst();

            // Iterate over the result set
            while (resultSet.next()) {
                int tid = resultSet.getInt("TID");
                String tname = resultSet.getString("TName");
                double salary = resultSet.getDouble("Salary");
                String subject = resultSet.getString("Subject");

                System.out.println("TID: " + tid + ", TName: " + tname + ", Salary: " + salary + ", Subject: " + subject);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
