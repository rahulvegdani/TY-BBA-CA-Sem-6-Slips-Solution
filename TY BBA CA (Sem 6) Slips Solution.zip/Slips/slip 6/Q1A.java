import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Q1A extends JFrame {
    private ImageIcon icon;
    private JLabel label;
    private boolean isVisible = false;

    public Q1A() {
        setTitle("Blinking Image");
        setSize(300, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Load the image
        icon = new ImageIcon("eye.png"); // Replace "image.png" with the path to your image

        // Create a label with the image
        label = new JLabel(icon);
        label.setBounds(50, 50, icon.getIconWidth(), icon.getIconHeight());

        // Add label to the frame
        getContentPane().add(label);

        // Create and start a timer to toggle the visibility of the image
        Timer timer = new Timer(500, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                isVisible = !isVisible;
                label.setVisible(isVisible);
            }
        });
        timer.start();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new Q1A().setVisible(true);
            }
        });
    }
}
