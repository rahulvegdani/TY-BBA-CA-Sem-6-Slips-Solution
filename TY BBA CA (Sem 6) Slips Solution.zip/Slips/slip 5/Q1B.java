import java.applet.Applet;
import java.awt.Color;
import java.awt.Graphics;

public class Q1B extends Applet implements Runnable {
    private Thread thread;
    private volatile boolean running = true; // Flag to control thread execution
    private Color currentColor; // Declare currentColor variable

    public void init() {
        setSize(200, 400); // Set applet size
        currentColor = Color.RED; // Initial color is red
    }

    public void start() {
        thread = new Thread(this);
        thread.start(); // Start the animation thread
    }

    public void stop() {
        running = false; // Set the flag to stop the thread gracefully
    }

    public void run() {
        while (running) {
            try {
                // Change colors with a delay
                Thread.sleep(2000); // Wait for 2 seconds

                // Change to green
                currentColor = Color.GREEN;
                repaint();

                // Wait for 2 seconds
                Thread.sleep(2000);

                // Change to yellow
                currentColor = Color.YELLOW;
                repaint();

                // Wait for 1 second
                Thread.sleep(1000);

                // Change to red
                currentColor = Color.RED;
                repaint();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public void paint(Graphics g) {
        // Set background color
        setBackground(Color.WHITE);

        // Draw the traffic signal
        g.setColor(Color.BLACK);
        g.fillRect(80, 50, 40, 100); // Pole
        g.setColor(Color.GRAY);
        g.fillOval(90, 60, 20, 20); // Red light
        g.fillOval(90, 90, 20, 20); // Yellow light
        g.fillOval(90, 120, 20, 20); // Green light

        // Set the current light color
        g.setColor(currentColor);

        // Draw the current light
        if (currentColor == Color.RED) {
            g.fillOval(90, 60, 20, 20); // Red light
        } else if (currentColor == Color.YELLOW) {
            g.fillOval(90, 90, 20, 20); // Yellow light
        } else if (currentColor == Color.GREEN) {
            g.fillOval(90, 120, 20, 20); // Green light
        }
    }
}
