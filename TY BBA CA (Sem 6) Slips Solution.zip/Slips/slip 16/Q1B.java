import java.sql.*;
import java.util.Scanner;

public class Q1B {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/slip16", "root", "root");

            // Accept details of at least 5 students
            for (int i = 0; i < 5; i++) {
                System.out.println("Enter details for Student " + (i + 1) + ":");
                System.out.print("Roll No: ");
                int rollNo = scanner.nextInt();
                System.out.print("Name: ");
                String name = scanner.next();
                System.out.print("Percentage: ");
                double percentage = scanner.nextDouble();

                // Insert student details into the database
                PreparedStatement insertStatement = connection.prepareStatement("INSERT INTO Students (rno, sname, per) VALUES (?, ?, ?)");
                insertStatement.setInt(1, rollNo);
                insertStatement.setString(2, name);
                insertStatement.setDouble(3, percentage);
                insertStatement.executeUpdate();
                insertStatement.close();
            }

            // Retrieve details of student with highest percentage
            PreparedStatement selectStatement = connection.prepareStatement("SELECT * FROM Students WHERE per = (SELECT MAX(per) FROM Students)");
            ResultSet resultSet = selectStatement.executeQuery();

            System.out.println("Details of student with highest percentage:");
            while (resultSet.next()) {
                int rollNo = resultSet.getInt("rno");
                String name = resultSet.getString("sname");
                double percentage = resultSet.getDouble("per");
                System.out.println("Roll No: " + rollNo + ", Name: " + name + ", Percentage: " + percentage);
            }

            selectStatement.close();
            connection.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
