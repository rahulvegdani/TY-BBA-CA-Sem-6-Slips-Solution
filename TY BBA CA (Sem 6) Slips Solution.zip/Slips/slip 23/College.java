public class College {
    private int cid;
    private String cName;
    private String address;
    private int year;

    public College(int cid, String cName, String address, int year) {
        this.cid = cid;
        this.cName = cName;
        this.address = address;
        this.year = year;
    }

    public int getCid() {
        return cid;
    }

    public String getCName() {
        return cName;
    }

    public String getAddress() {
        return address;
    }

    public int getYear() {
        return year;
    }
}
