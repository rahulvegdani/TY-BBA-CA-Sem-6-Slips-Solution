import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;

public class CollegeDetailsGUI extends JFrame {
    private JTable table;
    private DefaultTableModel model;

    public CollegeDetailsGUI(ArrayList<College> colleges) {
        setTitle("College Details");
        setSize(500, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create table model
        model = new DefaultTableModel();
        model.addColumn("CID");
        model.addColumn("Name");
        model.addColumn("Address");
        model.addColumn("Year");

        // Populate table with data
        for (College college : colleges) {
            model.addRow(new Object[]{college.getCid(), college.getCName(), college.getAddress(), college.getYear()});
        }

        // Create JTable with the model
        table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);

        // Add table to the frame
        getContentPane().add(scrollPane, BorderLayout.CENTER);
    }

    public static void main(String[] args) {
        // Create some sample College objects
        ArrayList<College> colleges = new ArrayList<>();
        colleges.add(new College(1, "College A", "Address A", 2022));
        colleges.add(new College(2, "College B", "Address B", 2023));
        colleges.add(new College(3, "College C", "Address C", 2021));

        // Create and display the GUI
        SwingUtilities.invokeLater(() -> {
            CollegeDetailsGUI gui = new CollegeDetailsGUI(colleges);
            gui.setVisible(true);
        });
    }
}
