import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Q1B extends HttpServlet {
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Get existing cookies
        Cookie[] cookies = request.getCookies();
        boolean isCookiePresent = false;
        String hobby = "";

        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals("hobby")) {
                    isCookiePresent = true;
                    hobby = cookie.getValue();
                    break;
                }
            }
        }

        // HTML form with option buttons for hobbies
        out.println("<html><body>");
        out.println("<h2>Select Your Hobby</h2>");
        out.println("<form action='HobbySelectionServlet' method='post'>");
        out.println("<input type='radio' name='hobby' value='Painting' " + (hobby.equals("Painting") ? "checked" : "") + "> Painting<br>");
        out.println("<input type='radio' name='hobby' value='Drawing' " + (hobby.equals("Drawing") ? "checked" : "") + "> Drawing<br>");
        out.println("<input type='radio' name='hobby' value='Singing' " + (hobby.equals("Singing") ? "checked" : "") + "> Singing<br>");
        out.println("<input type='radio' name='hobby' value='Swimming' " + (hobby.equals("Swimming") ? "checked" : "") + "> Swimming<br>");
        out.println("<input type='submit' value='Submit'>");
        out.println("<input type='reset' value='Reset'>");
        out.println("</form>");

        // Write cookie if not already present
        if (!isCookiePresent) {
            String selectedHobby = request.getParameter("hobby");
            if (selectedHobby != null && !selectedHobby.isEmpty()) {
                Cookie cookie = new Cookie("hobby", selectedHobby);
                response.addCookie(cookie);
            }
        }

        out.println("</body></html>");
        out.close();
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
