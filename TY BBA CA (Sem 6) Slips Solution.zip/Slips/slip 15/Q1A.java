public class Q1A {
    public static void main(String[] args) {
        char startChar = 'a';
        char endChar = 'z';

        for (char ch = startChar; ch <= endChar; ch++) {
            System.out.print(ch + " ");
            try {
                Thread.sleep(2000); // Sleep for 2 seconds (2000 milliseconds)
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
