import java.sql.*;

public class Q1A {
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost/your_database"; // Replace "your_database" with your database name
    static final String USER = "username"; // Replace "username" with your username
    static final String PASS = "password"; // Replace "password" with your password

    public static void main(String[] args) {
        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            // Register JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Open a connection
            System.out.println("Connecting to database...");
            conn = DriverManager.getConnection(DB_URL, USER, PASS);

            // Create table Emp if not exists
            String createTableSql = "CREATE TABLE IF NOT EXISTS Emp (" +
                    "ENo INT NOT NULL AUTO_INCREMENT PRIMARY KEY, " +
                    "EName VARCHAR(50), " +
                    "Sal FLOAT)";
            stmt = conn.prepareStatement(createTableSql);
            stmt.executeUpdate();
            System.out.println("Table created successfully.");

            // Insert records into Emp table
            String insertRecordSql = "INSERT INTO Emp (EName, Sal) VALUES (?, ?)";
            stmt = conn.prepareStatement(insertRecordSql);
            stmt.setString(1, "John");
            stmt.setFloat(2, 50000.0f);
            stmt.executeUpdate();
            System.out.println("Record inserted successfully.");

        } catch (SQLException se) {
            // Handle errors for JDBC
            se.printStackTrace();
        } catch (Exception e) {
            // Handle errors for Class.forName
            e.printStackTrace();
        } finally {
            // Finally block to close resources
            try {
                if (stmt != null) stmt.close();
            } catch (SQLException se2) {
            }
            try {
                if (conn != null) conn.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
        System.out.println("Goodbye!");
    }
}
