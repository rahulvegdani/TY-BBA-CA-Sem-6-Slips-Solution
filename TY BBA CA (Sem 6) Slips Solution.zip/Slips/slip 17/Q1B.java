import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Q1B {
    public static void main(String[] args) {
        String filePath = "rahul.txt"; // Replace with the path to your file

        try {
            Path path = Paths.get(filePath);
            if (Files.exists(path)) {
                System.out.println("File found. Contents:");
                displayFileContents(path);
            } else {
                System.out.println("File Not Found");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void displayFileContents(Path filePath) throws IOException {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath.toFile()))) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        }
    }
}
