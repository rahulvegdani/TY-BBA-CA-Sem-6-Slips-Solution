import java.sql.*;

public class Q1A {
    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("Usage: java DeleteEmployee <EmployeeID>");
            return;
        }

        int employeeID = Integer.parseInt(args[0]);

        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/your_database_name", "root", "your_password");
            PreparedStatement statement = connection.prepareStatement("DELETE FROM Employee WHERE ENo = ?");
            statement.setInt(1, employeeID);

            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Employee with ID " + employeeID + " deleted successfully.");
            } else {
                System.out.println("No employee found with ID " + employeeID + ".");
            }

            statement.close();
            connection.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}
